ITEM.name = "Base Blueprint"
ITEM.category = "Чертежи"
ITEM.model = "models/toussaint_paper6.mdl"