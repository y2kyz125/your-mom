ATTRIBUTE.name = "Кулинария"
ATTRIBUTE.desc = "Умение готовить еду."