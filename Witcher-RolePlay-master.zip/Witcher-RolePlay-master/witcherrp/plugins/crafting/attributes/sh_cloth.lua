ATTRIBUTE.name = "Ткацкое ремесло"
ATTRIBUTE.desc = "Умение создавать изделия из ткани."