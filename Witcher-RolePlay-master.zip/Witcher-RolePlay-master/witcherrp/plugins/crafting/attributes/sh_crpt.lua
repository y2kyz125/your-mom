ATTRIBUTE.name = "Древообработка"
ATTRIBUTE.desc = "Умение создавать изделия из дерева."