ATTRIBUTE.name = "Алхимия"
ATTRIBUTE.desc = "Умение создавать отвары, припарки и зелья."