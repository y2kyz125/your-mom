ATTRIBUTE.name = "Кузнечное ремесло"
ATTRIBUTE.desc = "Умение создавать изделия из металла."