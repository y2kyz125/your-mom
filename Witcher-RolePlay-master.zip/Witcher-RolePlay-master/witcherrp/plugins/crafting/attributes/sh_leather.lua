ATTRIBUTE.name = "Кожевенное ремесло"
ATTRIBUTE.desc = "Умение создавать изделия из кожи."