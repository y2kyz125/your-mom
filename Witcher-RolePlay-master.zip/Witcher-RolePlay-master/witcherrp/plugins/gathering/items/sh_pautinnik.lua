ITEM.name = "Паутинник"
ITEM.desc = "Может использоваться как алхимический ингридиент"
ITEM.model = "models/items/jewels/purses/little_purse.mdl"