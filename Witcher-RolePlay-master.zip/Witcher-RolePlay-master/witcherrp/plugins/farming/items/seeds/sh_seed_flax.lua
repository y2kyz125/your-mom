ITEM.name = "Семена льна"
ITEM.model = "models/items/jewels/purses/big_purse.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "Небольшой мешочек с семенами льна."
ITEM.PlantModel = "models/aoc_trees/aoc_lowveg4.mdl"
ITEM.BadGathering = {"seed_flax"}
ITEM.CommonGathering = {"seed_flax","flax"}
ITEM.MasterGathering = {"seed_flax","seed_flax","flax"}

