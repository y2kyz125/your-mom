ATTRIBUTE.name = "Земледелие"
ATTRIBUTE.desc = "Влияет на вероятность успешного сбора урожая."