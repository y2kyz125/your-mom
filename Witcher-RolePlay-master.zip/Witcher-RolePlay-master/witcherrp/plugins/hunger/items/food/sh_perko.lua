ITEM.name = "Пёркёльт"
ITEM.desc = "Тушеная с луком и специями курица."
ITEM.category = "Еда"
ITEM.model = "models/plates7.mdl"
ITEM.hunger = 60
ITEM.quantity = 4
ITEM.emptyItem = "bowl"