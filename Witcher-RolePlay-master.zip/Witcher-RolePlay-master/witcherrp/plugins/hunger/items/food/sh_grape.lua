ITEM.name = "Виноградная лоза"
ITEM.desc = "Гроздь желтоватого сладкого винограда."
ITEM.category = "Еда"
ITEM.model = "models/fruit4.mdl"
ITEM.hunger = 5
ITEM.thirst = 5
ITEM.quantity = 5