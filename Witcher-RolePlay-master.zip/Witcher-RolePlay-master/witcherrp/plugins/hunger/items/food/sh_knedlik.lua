ITEM.name = "Кнедлик"
ITEM.desc = "Отварное изделие из картофеля по форме напоминающее батон."
ITEM.category = "Еда"
ITEM.model = "models/items/provisions/bread01/bread01_cooked.mdl"
ITEM.hunger = 50
ITEM.quantity = 3