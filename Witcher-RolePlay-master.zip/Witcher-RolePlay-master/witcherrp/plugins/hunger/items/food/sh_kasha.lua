ITEM.name = "Пшеничная каша"
ITEM.desc = "Вкусная и полезная пища."
ITEM.category = "Еда"
ITEM.model = "models/plates7.mdl"
ITEM.hunger = 50
ITEM.quantity = 3
ITEM.emptyItem = "bowl"