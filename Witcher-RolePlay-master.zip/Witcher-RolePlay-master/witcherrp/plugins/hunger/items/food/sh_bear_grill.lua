ITEM.name = "Тушеная медвежатина"
ITEM.desc = "Не дели шкуру неубитого медведя. Неизвестно, распространяется ли эта поговорка на мясо."
ITEM.category = "Еда"
ITEM.model = "models/aoc_outdoor/meat_03.mdl"
ITEM.hunger = 80
ITEM.thirst = 0
ITEM.quantity = 4