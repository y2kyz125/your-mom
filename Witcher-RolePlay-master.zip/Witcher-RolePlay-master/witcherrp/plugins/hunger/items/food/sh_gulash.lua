ITEM.name = "Гуляш"
ITEM.desc = "Очень вкусный и ароматный гуляш."
ITEM.category = "Еда"
ITEM.model = "models/plates7.mdl"
ITEM.hunger = 75
ITEM.quantity = 3
ITEM.emptyItem = "bowl"