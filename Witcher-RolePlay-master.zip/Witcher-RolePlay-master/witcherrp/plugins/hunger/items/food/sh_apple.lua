ITEM.name = "Яблоко"
ITEM.desc = "Сладкое, красное, сочное яблочко."
ITEM.category = "Еда"
ITEM.model = "models/items/provisions/fruits/red_apple.mdl"
ITEM.hunger = 15
ITEM.thirst = 15
ITEM.price = 5
ITEM.quantity = 1
ITEM.permit = "food"

