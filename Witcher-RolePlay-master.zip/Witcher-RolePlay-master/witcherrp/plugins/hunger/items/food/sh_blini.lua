ITEM.name = "Блины"
ITEM.desc = "Если нет тарелки, можно есть с лопаты."
ITEM.category = "Еда"
ITEM.model = "models/items/provisions/pie/pie.mdl"
ITEM.hunger = 35
ITEM.quantity = 3