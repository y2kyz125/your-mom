ITEM.name = "Чевапчичи"
ITEM.desc = "Колбаски из мяса с луком, хорошо идут с хлебом."
ITEM.category = "Еда"
ITEM.model = "models/aoc_outdoor/sausage_01.mdl"
ITEM.hunger = 20
ITEM.thirst = 0
ITEM.quantity = 2