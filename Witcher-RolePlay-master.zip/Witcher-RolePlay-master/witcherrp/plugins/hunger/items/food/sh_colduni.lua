ITEM.name = "Колдуны"
ITEM.desc = "Простейшая еда обладающая волшебным вкусом."
ITEM.category = "Еда"
ITEM.model = "models/props_phx/misc/potato.mdl"
ITEM.hunger = 40
ITEM.quantity = 2