ITEM.name = "Гювеч"
ITEM.desc = "Куриный гуляш с добавлением лука, помидоров и картофеля."
ITEM.category = "Еда"
ITEM.model = "models/plates7.mdl"
ITEM.hunger = 60
ITEM.quantity = 5
ITEM.emptyItem = "bowl"