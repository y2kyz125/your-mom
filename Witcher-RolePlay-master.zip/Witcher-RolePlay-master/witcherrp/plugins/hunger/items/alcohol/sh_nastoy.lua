ITEM.name = "Самогон из мандрагоры"
ITEM.desc = "Уникальный алкоголь."
ITEM.force = 90
ITEM.thirst = 15
ITEM.quantity = 3