ITEM.name = "Вино"
ITEM.desc = "Простое красное вино."
ITEM.model = "models/toussaint_bottle3.mdl"
ITEM.force = 40
ITEM.thirst = 25
ITEM.quantity = 3