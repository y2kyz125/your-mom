ITEM.name = "Спирт"
ITEM.desc = "Чистейший спирт. Можно выпить или использовать для алхимии."
ITEM.model = "models/toussaint_bottle5.mdl"
ITEM.force = 80
ITEM.thirst = 15
ITEM.quantity = 3