ITEM.name = "Нильфгаардская лимонная водка"
ITEM.desc = "Водка, очень популярная в империи Нильфгаард. Нордлинги пьют её за погибель чёрных."
ITEM.model = "models/toussaint_bottle4.mdl"
ITEM.force = 75
ITEM.thirst = 15
ITEM.quantity = 5