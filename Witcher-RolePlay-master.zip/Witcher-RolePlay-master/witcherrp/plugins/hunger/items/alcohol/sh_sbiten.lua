ITEM.name = "Сбитень"
ITEM.desc = "Выпейте это если не хватает храбрости кого нибудь взбить."
ITEM.model = "models/toussaint_bottle8.mdl"
ITEM.force = 10
ITEM.thirst = 40
ITEM.quantity = 3