ITEM.name = "Пиво"
ITEM.desc = "Алкогольный напиток из пшеницы."
ITEM.force = 30
ITEM.thirst = 15
ITEM.quantity = 3