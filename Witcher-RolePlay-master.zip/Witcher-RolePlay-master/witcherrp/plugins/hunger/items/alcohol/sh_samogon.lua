ITEM.name = "Самогон"
ITEM.desc = "Очень крепкий самогон."
ITEM.force = 75
ITEM.thirst = 15
ITEM.quantity = 3