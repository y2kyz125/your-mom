ITEM.name = "Алкагест"
ITEM.desc = "Высококачественная основа для эликсиров."
ITEM.model = "models/toussaint_bottle9.mdl"
ITEM.force = 80
ITEM.thirst = 15
ITEM.quantity = 3