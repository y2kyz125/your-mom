ITEM.name = "Квас"
ITEM.desc = "Приятно пахнет хлебом."
ITEM.force = 10
ITEM.thirst = 50
ITEM.quantity = 3


