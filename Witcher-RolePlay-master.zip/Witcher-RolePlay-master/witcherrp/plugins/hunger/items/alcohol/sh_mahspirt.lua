ITEM.name = "Махакамский спирт"
ITEM.desc = "Обжигает горло не хуже огня."
ITEM.model = "models/toussaint_bottle8.mdl"
ITEM.force = 90
ITEM.thirst = 15
ITEM.quantity = 3