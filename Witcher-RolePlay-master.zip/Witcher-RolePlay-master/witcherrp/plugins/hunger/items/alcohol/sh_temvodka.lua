ITEM.name = "Темерская ржаная водка"
ITEM.desc = "Местные пьянчуги называют ржаную водку своим хлебом насущным."
ITEM.model = "models/toussaint_bottle4.mdl"
ITEM.force = 75
ITEM.thirst = 15
ITEM.quantity = 5