ITEM.name = "Ракия"
ITEM.desc = "Вопреки названию, делается из яблок, а не из раков."
ITEM.model = "models/toussaint_bottle8.mdl"
ITEM.force = 70
ITEM.thirst = 15
ITEM.quantity = 3