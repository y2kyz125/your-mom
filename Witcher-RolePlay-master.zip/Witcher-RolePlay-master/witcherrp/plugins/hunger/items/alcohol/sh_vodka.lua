ITEM.name = "Водка"
ITEM.desc = "Бутылка с прозрачной жидкостью."
ITEM.model = "models/toussaint_bottle4.mdl"
ITEM.force = 60
ITEM.thirst = 15
ITEM.quantity = 5