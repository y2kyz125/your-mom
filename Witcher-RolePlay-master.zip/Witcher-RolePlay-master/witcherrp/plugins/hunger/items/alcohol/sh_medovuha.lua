ITEM.name = "Медовуха"
ITEM.desc = "Алкогольный напиток из меда."
ITEM.force = 50
ITEM.thirst = 15
ITEM.quantity = 3