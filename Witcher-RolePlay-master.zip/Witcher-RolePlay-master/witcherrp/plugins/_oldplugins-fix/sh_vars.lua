nut.config.menuWidth = 0.5
nut.config.menuHeight = 0.5
nut.config.mainColor = nut.config.get("color", Color(255, 255, 255, 255))
nut.config.deathTime = nut.config.get("spawnTime", 5)
nut.config.buyDelay = 1
nut.config.runSpeed = nut.config.get("runSpeed")