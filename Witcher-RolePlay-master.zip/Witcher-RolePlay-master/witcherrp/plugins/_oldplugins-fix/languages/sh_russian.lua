NAME = "Русский"
LANGUAGE = {
	May = "Май",
	Thursday = "Среда",
	Read = "Читать",
	missing_arg = "Вы предоставили недопустимое значение аргумента #%s.",
	Armor = "Броня",
	Ammunition = "Боеприпасы",
	Alcohol = "Алкоголь",
	literature = "Литература",
	Furniture = "Мебель",
	Permits = "Разрешения",
}