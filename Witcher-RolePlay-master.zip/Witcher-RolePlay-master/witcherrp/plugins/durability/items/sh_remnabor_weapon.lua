ITEM.name = "Набор для починки оружия"
ITEM.category = "Остальное"
ITEM.desc = "Короб, в котором находится все необходимое для починки оружия."
ITEM.model = "models/toussaint_box1.mdl"
ITEM.isRem = true