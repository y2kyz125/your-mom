ITEM.name = "Набор для починки брони"
ITEM.category = "Остальное"
ITEM.desc = "Короб, в котором находится все необходимое для починки доспехов."
ITEM.model = "models/toussaint_box1.mdl"
ITEM.isRem = true