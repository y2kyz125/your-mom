﻿ITEM.name = "Вилка"
ITEM.desc = "Обыкновенная вилка, в случае чего очень удобно чистить"
ITEM.model = "models/props/furnitures/mn/mn_fork/mn_fork.mdl"
ITEM.width = 1
ITEM.height = 1