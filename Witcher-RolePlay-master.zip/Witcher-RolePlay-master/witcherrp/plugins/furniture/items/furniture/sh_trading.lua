﻿ITEM.name = "Торговый стенд"
ITEM.desc = "Стенд из дерева, на него можно размещать все что угодно"
ITEM.model = "models/aoc_outdoor/merchant_table.mdl"
ITEM.width = 5
ITEM.height = 2