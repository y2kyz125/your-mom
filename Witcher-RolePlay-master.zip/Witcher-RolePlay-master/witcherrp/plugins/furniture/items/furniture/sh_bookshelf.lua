﻿ITEM.name = "Высокий шкаф с книгами"
ITEM.desc = "Высокий шкаф"
ITEM.model = "models/aoc_furniture/shelf03.mdl"
ITEM.width = 3
ITEM.height = 4