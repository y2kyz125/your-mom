﻿ITEM.name = "Серебряный кубок"
ITEM.desc = "Сосуд из серебра, пользуется популярностью среди буржуазии"
ITEM.model = "models/props/furnitures/mn/mn_tumbler/mn_tumbler.mdl"
ITEM.width = 1
ITEM.height = 1