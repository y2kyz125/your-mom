﻿ITEM.name = "Цветная торговая палатка"
ITEM.desc = "Палатка, полотно которой разукрашенно несколькими разными цветами, удобно сворачивается"
ITEM.model = "models/aoc_outdoor/merchant_produce.mdl"
ITEM.width = 5
ITEM.height = 1