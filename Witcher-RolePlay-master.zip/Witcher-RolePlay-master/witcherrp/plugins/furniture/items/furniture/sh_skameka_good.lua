﻿ITEM.name = "Хорошая скамейка"
ITEM.desc = "Скамейка, сделанная достаточно умелым плотником"
ITEM.model = "models/props/furnitures/humans/bench01_big.mdl"
ITEM.width = 3
ITEM.height = 1