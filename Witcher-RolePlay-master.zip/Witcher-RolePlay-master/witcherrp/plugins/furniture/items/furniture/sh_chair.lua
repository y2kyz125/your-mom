﻿ITEM.name = "Деревянный стул"
ITEM.desc = "Стул из самого обычного дерева. Материл не подвергался обработке, не прочен"
ITEM.model = "models/aoc_furniture/chair_02.mdl"
ITEM.width = 2
ITEM.height = 2