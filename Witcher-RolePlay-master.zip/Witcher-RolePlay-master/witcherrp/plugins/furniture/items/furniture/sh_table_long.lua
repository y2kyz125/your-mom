﻿
ITEM.name = "Хороший длинный стол"
ITEM.desc = "Качественный стол с металлическими подковками, достаточно длинный"
ITEM.model = "models/props/furnitures/mn/mn_tablebig.mdl"
ITEM.width = 5
ITEM.height = 2