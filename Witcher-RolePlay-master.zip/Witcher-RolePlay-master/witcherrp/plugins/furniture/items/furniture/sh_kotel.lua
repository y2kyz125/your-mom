﻿
ITEM.name = "Котелок"
ITEM.desc = "Металлический котелолок, можно подвесить на костер или плиту, приготовить что-нибудь"
ITEM.model = "models/props/furnitures/mn/mn_stewpan/mn_stewpan.mdl"
ITEM.width = 1
ITEM.height = 1