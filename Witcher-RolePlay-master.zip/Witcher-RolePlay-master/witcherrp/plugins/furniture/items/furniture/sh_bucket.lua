﻿ITEM.name = "Ведро"
ITEM.desc = "Мастерская работа"
ITEM.model = "models/aoc_objects/bucket_01.mdl"
ITEM.width = 1
ITEM.height = 1