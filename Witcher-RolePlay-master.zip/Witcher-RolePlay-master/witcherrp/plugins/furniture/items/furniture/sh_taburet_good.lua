﻿ITEM.name = "Хорошая табуретка"
ITEM.desc = "Табуретка, сделанная достаточно умелым плотником"
ITEM.model = "models/props/furnitures/humans/stool01.mdl"
ITEM.width = 2
ITEM.height = 2