﻿ITEM.name = "Канделябр"
ITEM.desc = "Латунный канделябр, на нем можно зажечь свечу"
ITEM.model = "models/aoc_objects/candle_01.mdl"
ITEM.width = 1
ITEM.height = 1