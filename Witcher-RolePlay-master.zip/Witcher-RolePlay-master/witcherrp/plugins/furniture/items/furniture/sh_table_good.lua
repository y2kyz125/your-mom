﻿ITEM.name = "Хороший стол"
ITEM.desc = "Хорошенький стол, такие часто используют публичные заведения"
ITEM.model = "models/props/furnitures/humans/table01.mdl"
ITEM.width = 4
ITEM.height = 2