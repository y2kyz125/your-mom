﻿ITEM.name = "Стол"
ITEM.desc = "Стол не стол."
ITEM.model = "models/props/furnitures/humans/l02_tablebench.mdl"
ITEM.width = 4
ITEM.height = 3