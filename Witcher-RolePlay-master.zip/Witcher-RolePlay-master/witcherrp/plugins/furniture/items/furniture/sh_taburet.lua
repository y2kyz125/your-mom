﻿ITEM.name = "Деревянная табуретка"
ITEM.desc = "Табуретка из дерева. Засадит занозу в ваше гузно"
ITEM.model = "models/aoc_breakables/stool_01.mdl"
ITEM.width = 2
ITEM.height = 2