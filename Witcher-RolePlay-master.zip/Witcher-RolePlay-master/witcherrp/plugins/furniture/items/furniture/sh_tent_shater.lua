﻿ITEM.name = "Палатка шатер"
ITEM.desc = "Очень удобная палатка, очень популярна в армиях из-за своих малых габаритов и простоты в использовании"
ITEM.model = "models/aoc_tents/aoc_tent2.mdl"
ITEM.width = 3
ITEM.height = 1