﻿ITEM.name = "Обычная торговая палатка"
ITEM.desc = "Обыкновеннейшая палатка, в таких начинали многие купцы и торговцы"
ITEM.model = "models/aoc_outdoor/merchant_generic.mdl"
ITEM.width = 5
ITEM.height = 1