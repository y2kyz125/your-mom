﻿ITEM.name = "Кровать"
ITEM.desc = "Деревянная кровать, хотя она по корману не каждому холопу"
ITEM.model = "models/aoc_furniture/bed_01.mdl"
ITEM.width = 4
ITEM.height = 2