﻿ITEM.name = "Деревянная скамейка"
ITEM.desc = "Скамейка как скамейка. Можно сесть. Можно и не сесть."
ITEM.model = "models/aoc_furniture/bench_01.mdl"
ITEM.width = 3
ITEM.height = 1