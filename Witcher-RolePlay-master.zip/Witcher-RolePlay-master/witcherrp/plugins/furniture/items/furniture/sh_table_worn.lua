﻿ITEM.name = "Старый деревянный стол"
ITEM.desc = "Довольно ветхий стол, доски которого уже готовы рассыпаться в пыль"
ITEM.model = "models/aoc_furniture/table_01.mdl"
ITEM.width = 4
ITEM.height = 2