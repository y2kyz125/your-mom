﻿ITEM.name = "Полосатая торговая палатка"
ITEM.desc = "Палатка в жёлто-черную полоску, удобно сворачивается"
ITEM.model = "models/aoc_outdoor/merchant_generic_02.mdl"
ITEM.width = 5
ITEM.height = 1