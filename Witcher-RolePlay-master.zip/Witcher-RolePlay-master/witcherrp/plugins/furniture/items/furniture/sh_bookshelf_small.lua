﻿ITEM.name = "Низкий шкаф с книгами"
ITEM.desc = "Обыкновенный низкий шкаф из дерева"
ITEM.model = "models/aoc_furniture/shelf04.mdl"
ITEM.width = 3
ITEM.height = 3
