﻿ITEM.name = "Хорошая двуспальная кровать"
ITEM.desc = "Обычно подобные вещи могут позволить себе только дворяне. Выполненна из качественного дерева и дорогой ткани"
ITEM.model = "models/props/archi/l02/l02_bed.mdl"
ITEM.width = 4
ITEM.height = 3