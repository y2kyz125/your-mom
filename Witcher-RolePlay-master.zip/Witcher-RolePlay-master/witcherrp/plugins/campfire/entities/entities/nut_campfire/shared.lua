DEFINE_BASECLASS("base_gmodentity");

ENT.Type = "anim";
ENT.Author = "[TEC]---==ANONIM-TEC==---";
ENT.PrintName = "Костер";
ENT.Category = "NutScript"
ENT.Spawnable = true;
ENT.AdminSpawnable = true;