ITEM.name = "Заготовка ключа"
ITEM.category = "Остальное"
ITEM.desc = "Заготовка, из которой можно сделать ключ любой формы."
ITEM.model = "models/aoc_objects/key_01.mdl"
ITEM.price = 30
ITEM.width = 1
ITEM.height = 1

ITEM.iconCam = {
	pos = Vector(78.25227355957, 68.268035888672, 47.486251831055),
	ang = Angle(25, 220, 0),
	fov = 4.3005635317871
}
