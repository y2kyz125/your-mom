﻿ITEM.name = "Доспех темерского арбалетчика"
ITEM.desc = "Средний доспех, который носится темерскими арбалетчиками."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_temerian_arbalest.mdl"
ITEM.price = 1750
ITEM.mass = 30
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .85,
	[DMG_SLASH] = .75,
	[DMG_CRUSH] = .80
}