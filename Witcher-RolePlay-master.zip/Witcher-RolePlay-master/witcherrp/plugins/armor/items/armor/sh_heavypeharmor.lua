﻿ITEM.name = "Тяжелая броня пехотинца"
ITEM.desc = "Тяжелый доспех, состоящий из топфхельма, кольчужного поддоспешника и тяжелоый стальной кирасы."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/aoc_player/crusader.mdl"
ITEM.price = 1750
ITEM.mass = 75
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .60,
	[DMG_SLASH] = .30,
	[DMG_CRUSH] = .20
}