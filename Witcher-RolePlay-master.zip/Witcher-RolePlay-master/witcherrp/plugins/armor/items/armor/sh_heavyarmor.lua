﻿ITEM.name = "Тяжелые латы"
ITEM.desc = "Тяжелый доспех, который обычно носят бедные рыцари."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/got/gotknight3.mdl"
ITEM.price = 1750
ITEM.mass = 60
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .60,
	[DMG_SLASH] = .40,
	[DMG_CRUSH] = .85
}