﻿ITEM.name = "Тяжелый доспех из Редании"
ITEM.desc = "Тяжелый доспех, выполненный в цветах реданского герба. На шлеме закреплены 2 рога."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/aoc_player/mason_crusader/mason_crusader.mdl"
ITEM.price = 1750
ITEM.mass = 60
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .65,
	[DMG_SLASH] = .55,
	[DMG_CRUSH] = .7
}