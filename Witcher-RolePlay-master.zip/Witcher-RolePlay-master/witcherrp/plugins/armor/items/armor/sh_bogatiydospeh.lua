﻿ITEM.name = "Богатый доспех"
ITEM.desc = "Средний доспех, сделанный, похоже, по заказу какого-то лорда или барона."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/hgn/cru/lorda1.mdl"
ITEM.price = 1750
ITEM.mass = 50
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .70,
	[DMG_SLASH] = .45,
	[DMG_CRUSH] = .70
}