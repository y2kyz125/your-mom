﻿ITEM.name = "Броня ополченца"
ITEM.desc = "Легкий доспех, сделанный из самых дешевых материалов, дабы продлить жизнь бойца на дополнительные 10 секунд, если не меньше."
ITEM.category = "Armor"
ITEM.model = "models/container7.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_etterick_regular.mdl"
ITEM.price = 1750
ITEM.mass = 30
ITEM.armorType = 1

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .90,
	[DMG_SLASH] = .80,
	[DMG_CRUSH] = .90
}