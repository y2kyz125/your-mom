﻿ITEM.name = "Броня темерского ополченца"
ITEM.desc = "Средний доспех. На груди изображен герб Темерии."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_temerian_regular.mdl"
ITEM.price = 1750
ITEM.mass = 30
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .75,
	[DMG_SLASH] = .75,
	[DMG_CRUSH] = .90
}