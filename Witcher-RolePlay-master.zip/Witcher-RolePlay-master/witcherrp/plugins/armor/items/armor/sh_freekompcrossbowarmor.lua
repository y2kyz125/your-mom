﻿ITEM.name = "Доспех арбалетчика Вольной Компании"
ITEM.desc = "Средний доспех, который используется элитными арбалетчиками Вольной Компании."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_etterick_arbalest.mdl"
ITEM.price = 1750
ITEM.mass = 40
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .75,
	[DMG_SLASH] = .60,
	[DMG_CRUSH] = .75
}