﻿ITEM.name = "Броня с Ундвика"
ITEM.desc = "Средний доспех, который носят славные войны с островов Скеллиге."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/hgn/cru/guard.mdl"
ITEM.price = 1750
ITEM.mass = 60
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .90,
	[DMG_SLASH] = .55,
	[DMG_CRUSH] = .80
}