﻿ITEM.name = "Нильфгаардская чешуйчатая броня пехотинца"
ITEM.desc = "Средний доспех, которым оснащены солдаты Нильфгаарда."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/aoc_player/e_footman.mdl"
ITEM.price = 1750
ITEM.def1 = 20
ITEM.def2 = 35
ITEM.def3 = 15
ITEM.mass = 35
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .80,
	[DMG_SLASH] = .65,
	[DMG_CRUSH] = .85
}