﻿ITEM.name = "Доспех цинтрийского кавалериста"
ITEM.desc = "Тяжелый доспех, элементы которого выполнены из качественных стальных пластин."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/aoc_player/gknight.mdl"
ITEM.price = 1750
ITEM.mass = 85
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .40,
	[DMG_SLASH] = .50,
	[DMG_CRUSH] = .85
}