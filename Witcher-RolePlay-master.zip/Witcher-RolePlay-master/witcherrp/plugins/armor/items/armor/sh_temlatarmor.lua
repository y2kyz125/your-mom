﻿ITEM.name = "Доспехи темерского латника"
ITEM.desc = "Тяжелый доспех, богато украшенный темерскими лилиями."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_temerian_knight.mdl"
ITEM.price = 1750
ITEM.mass = 70
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .50,
	[DMG_SLASH] = .25,
	[DMG_CRUSH] = .85
}