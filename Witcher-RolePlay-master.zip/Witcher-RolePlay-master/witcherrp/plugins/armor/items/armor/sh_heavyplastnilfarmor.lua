﻿ITEM.name = "Тяжелый пластинчатый доспех из Нильфгаарда"
ITEM.desc = "Тяжелый доспех, части которого созданы из стальных пластин."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/aoc_player/eknight.mdl"
ITEM.price = 1750
ITEM.mass = 80
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .60,
	[DMG_SLASH] = .40,
	[DMG_CRUSH] = .85
}