﻿ITEM.name = "Доспех темерского десятника"
ITEM.desc = "Средний доспех, который носят десятники Темерии."
ITEM.category = "Armor"
ITEM.model = "models/container.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_temerian_regular2.mdl"
ITEM.price = 1750
ITEM.mass = 35
ITEM.armorType = 2

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .65,
	[DMG_SLASH] = .70,
	[DMG_CRUSH] = .85
}