﻿ITEM.name = "Улучшенные тяжелые латы"
ITEM.desc = "Тяжелый доспех, являющийся усиленным аналогом тяжелых лат."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/got/gotknight4.mdl"
ITEM.price = 1750
ITEM.mass = 60

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .50,
	[DMG_SLASH] = .30,
	[DMG_CRUSH] = .75
}