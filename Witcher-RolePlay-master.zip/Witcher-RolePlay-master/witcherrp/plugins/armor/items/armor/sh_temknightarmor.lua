﻿ITEM.name = "Латы темерского рыцаря"
ITEM.desc = "Тяжелый доспех, который носят темерские рыцари."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/got/gotknight5.mdl"
ITEM.price = 1750
ITEM.mass = 70
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .50,
	[DMG_SLASH] = .20,
	[DMG_CRUSH] = .85
}