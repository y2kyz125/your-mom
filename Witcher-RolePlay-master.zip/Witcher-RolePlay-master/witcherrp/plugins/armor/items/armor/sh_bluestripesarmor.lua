﻿ITEM.name = "Броня бойца 'Синих Полосок'"
ITEM.desc = "Легкий доспех, который носят солдаты особого темерского отряда 'Синие Полоски'."
ITEM.category = "Armor"
ITEM.model = "models/container7.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.SetModel = "models/witcher2soldiers/tw2_bluestripes_2.mdl"
ITEM.price = 1750
ITEM.armorclass = "vest"
ITEM.mass = 35
ITEM.armorType = 2

ITEM.resistance = {
	[DMG_CLUB] = .70,
	[DMG_SLASH] = .60,
	[DMG_CRUSH] = .65
}