﻿ITEM.name = "Рыцарские латы"
ITEM.desc = "Тяжелый доспех, который обычно носят рыцари из Туссента."
ITEM.category = "Armor"
ITEM.model = "models/container2.mdl"
ITEM.width = 3
ITEM.height = 2
ITEM.SetModel = "models/got/gotknight1.mdl"
ITEM.price = 1750
ITEM.mass = 80
ITEM.armorType = 3

ITEM.armorclass = "vest"
ITEM.resistance = {
	[DMG_CLUB] = .50,
	[DMG_SLASH] = .25,
	[DMG_CRUSH] = .75
}