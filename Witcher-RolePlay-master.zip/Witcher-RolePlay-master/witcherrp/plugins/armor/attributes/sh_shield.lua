ATTRIBUTE.name = "Щиты"
ATTRIBUTE.desc = "Умение блокировать урон щитами."