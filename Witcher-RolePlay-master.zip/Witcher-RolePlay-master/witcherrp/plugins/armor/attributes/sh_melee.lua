ATTRIBUTE.name = "Рукопашный бой"
ATTRIBUTE.desc = "Умение сражаться на кулаках."