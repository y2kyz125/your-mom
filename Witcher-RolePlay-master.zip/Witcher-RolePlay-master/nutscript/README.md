[![Join the chat at https://gitter.im/Chessnut/NutScript](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/Chessnut/NutScript?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

## Introduction
NutScript 1.1 is the re-working of the original NutScript framework to provide a better back-end. This should include more efficient code and overall benefits to the way the framework functioned and/or performed.

## Documentation
Check out the Wiki on the side tab to the right for documentation.

## Got more questions?
Visit http://nutscript.rocks for the official NutScript website which includes forums for discussing Nutscript.
