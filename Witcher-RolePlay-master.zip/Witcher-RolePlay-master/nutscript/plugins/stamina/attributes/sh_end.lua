ATTRIBUTE.name = "Выносливость"
ATTRIBUTE.desc = "Влияет на длительность бега."