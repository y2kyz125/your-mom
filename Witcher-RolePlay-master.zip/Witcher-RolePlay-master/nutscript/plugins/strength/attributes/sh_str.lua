ATTRIBUTE.name = "Сила"
ATTRIBUTE.desc = "Влияет на урон в ближнем бою."